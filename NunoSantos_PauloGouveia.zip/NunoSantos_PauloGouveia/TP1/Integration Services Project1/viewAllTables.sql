Select *
From DimCategorias

Select *
From DimClientes

Select *
From DimFornecedores

Select *
From FactosEncomendas

Select *
From FactosVendas


